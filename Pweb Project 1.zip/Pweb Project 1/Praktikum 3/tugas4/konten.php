<div class="py-5" >
    <div class="container">
      <div class="row">
        <div class="col-md-8 w-100 h-50" >
          <h3>TENTANG SILOKERNF</h3>
          <div class="row">
            <div class="col-md-12">
              <p class="lead mb-4">Lowongan pekerjaan adalah Jenis lapangan pekerjaan yang tersedia bagi para pencari kerja khususnya Lulusan STT TERPADU NURUL FIKRI dan disertai syarat-syarat tertentu.</p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="col-md-12 h-50">
                  <div class="row">
                    <div class="col-md-6">
                      <h2>Berita Terbaru 1</h2>
                    </div>
                    <div class="col-md-6">
                      <h2 class="">Berita Terbaru 2</h2>
                    </div>
                  </div>
                  <div class="col-lg-12 p-4 w-100 h-100">
                    <div class="row">
                      <div class="col-md-6 h-100">
                        <div class="row">
                          <div class="col-md-6 h-100"><img class="img-fluid d-block" src="Photo/bca.jpg"></div>
                          <div class="col-md-6">
                            <p class="mb-0">PT BCA Backend Website , Fresh Graduate , min IPK 3.00 , Good Looking ,S.kom atau................</p>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="row h-100">
                          <div class="col-md-6"><img class="img-fluid d-block" src="Photo/coding.jpg"></div>
                          <div class="col-md-6">
                            <p class="mb-0">PT Mahir Coding Website Security , Have Great Communitace with team , can work..........</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!----NewsRightSide---->
        <div class="col-md-4" style="	background-color: white;	background-position: top left;	background-size: 100%;	background-repeat: repeat;"><a href="#" class="list-group-item list-group-item-action active" style="	background-color: rgb(27, 105, 196);	background-position: top left;	background-size: 100%;	background-repeat: repeat;"> Link Berita Terbaru</a>
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="col-md-12">
                  <a href="https://www.liputan6.com/bisnis/read/4859558/berdikari-buka-lowongan-terbaru-nih-buat-lulusan-smk-hingga-d3" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="Photo/berita1.webp" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-md-8 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">Berdikari Buka Lowongan Terbaru Nih Buat Lulusan SMK hingga D3</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">14 Januari 2022 12.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <a href="https://www.liputan6.com/bisnis/read/4857513/ada-lowongan-di-kawasan-industri-batas-waktunya-28-januari-2022" class="list-group-item list-group-item-action grup-post-populer">
                <div class="">
                    <div class="row">
                        <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                            <img src="Photo/berita2.webp" class="img-fluid" alt="...">
                        </div>
                        <div class="col-7 col-md-8 col-lg-9 col-xl-9">
                            <div class="ket-populer">
                                <h5 class="">Ada Lowongan di Kawasan Industri, Batas Waktunya 28 Januari 2022</h5>
                                <p class=""></p>
                                <p class="card-text"><small class="text-muted">12 Januari 12.00</small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <a href="https://www.liputan6.com/bisnis/read/4856535/intip-lowongan-kerja-terbaru-kimia-farma-buat-lulusan-baru-nih" class="list-group-item list-group-item-action grup-post-populer">
                <div class="">
                    <div class="row">
                        <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                            <img src="Photo/berita3.webp" class="img-fluid" alt="...">
                        </div>
                        <div class="col-7 col-md-8 col-lg-9 col-xl-9">
                            <div class="ket-populer">
                                <h5 class="">Intip Lowongan Kerja Terbaru Kimia Farma buat Lulusan Baru Nih</h5>
                                <p class=""></p>
                                <p class="card-text"><small class="text-muted">11 Januari 2022 17.00</small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            </div>
          </div>
          <div class="row">
            <a href="https://www.liputan6.com/bisnis/read/4853561/minat-kerja-bidang-keuangan-dicoba-lowongan-kerja-di-anak-usaha-bank-mandiri" class="list-group-item list-group-item-action grup-post-populer">
              <div class="">
                  <div class="row">
                      <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                          <img src="Photo/berita5.webp" class="img-fluid" alt="...">
                      </div>
                      <div class="col-7 col-md-8 col-lg-9 col-xl-9">
                          <div class="ket-populer">
                              <h5 class="">Minat Kerja Bidang Keuangan, Dicoba Lowongan Kerja di Anak Usaha Bank Mandiri</h5>
                              <p class=""></p>
                              <p class="card-text"><small class="text-muted">7 Januari 2022 13.00</small>
                              </p>
                          </div>
                      </div>
                  </div>
              </div>
          </a>
          </div>
          <div class="row">
             <a href="https://www.liputan6.com/bisnis/read/4852686/kemenko-perekonomian-buka-lowongan-kerja-bergaji-rp-105-juta-minat" class="list-group-item list-group-item-action grup-post-populer">
                        <div class="">
                            <div class="row">
                                <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                    <img src="Photo/berita6.webp" class="img-fluid" alt="...">
                                </div>
                                <div class="col-7 col-md-8 col-lg-9 col-xl-9">
                                    <div class="ket-populer">
                                        <h5 class="">Kemenko Perekonomian Buka Lowongan Kerja Bergaji Rp 10,5 Juta, Minat?</p>
                                        <p class="card-text"><small class="text-muted"> 6 Januari 2022 13.10</small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-3 h-25" >
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center d-md-flex align-items-center" style="	background-image: linear-gradient(to bottom, #efcead, #efcead);	background-position: top left;	background-size: 100%;	background-repeat: repeat;">
          <div class="row" style="	background-image: linear-gradient(to bottom, #efcead, #efcead);	background-position: top left;	background-size: 100%;	background-repeat: repeat;">
          </div>
        </div>
      </div>
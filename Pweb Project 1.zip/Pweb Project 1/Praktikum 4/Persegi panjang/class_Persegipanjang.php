<?php

class Luas {

  public function persegi_panjang($p, $l) {
    return $p * $l;
  }
  }

class Keliling {

    public function persegi_panjang1($p, $l) {
      return 2* ($p + $l);
    }
    }
  

?>